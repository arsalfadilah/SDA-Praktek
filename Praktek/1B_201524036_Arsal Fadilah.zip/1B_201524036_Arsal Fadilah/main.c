#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include "list_queue.h"

int Menu(){
    int x;
    printf("===================================\n");
    printf("| Program By : Arsal Fadilah V.01 |\n");
    printf("===================================\n");
    printf("||     PENDAFTARAN VAKSINASI     ||\n");
    printf("||  1. Tambah Pendaftar          ||\n");
    printf("||  2. Tampilkan Pendaftar       ||\n");
    printf("||  3. Tampilkan Daftar Tunggu   ||\n");
    printf("||  4. Exit                      ||\n");
    printf("\n  Pilih Menu : ");
    scanf("%d", &x);
    return x;
}

void MenuSortList(List L){
    int fitur;
    List newTipe;

    printf("Filter by category :\n");
    printf("1. Dosen\n");
    printf("2. Guru\n");
    printf("3. BUMN\n");
    printf("4. Lansia\n");

    printf("Choose : ");scanf("%d", &fitur);

    switch(fitur){
        case 1:
            newTipe = FCopyList(L);
            //del semua yang bukan dosen. yg lainnya pun sama
            DelP(&newTipe, "DOSEN");
            sortListQueue(&newTipe);
            PrintInfo(newTipe);
            break;
        case 2:
            newTipe = FCopyList(L);
            DelP(&newTipe, "GURU");
            sortListQueue(&newTipe);
            PrintInfo(newTipe);
            break;
        case 3:
            newTipe = FCopyList(L);
            DelP(&newTipe, "BUMN");
            sortListQueue(&newTipe);
            PrintInfo(newTipe);
            break;
        case 4:
            newTipe = FCopyList(L);
            DelP(&newTipe, "LANSIA");
            sortListQueue(&newTipe);
            PrintInfo(newTipe);
            break;
        default:
            printf("Wrong Input");
            break;
    }

    printf("\n[ Back To Menu ]\n");

}

int main(){
    char ActiveSortCategory;
    List pendaftar, queue_list;
    CreateList(&pendaftar);

    system("cls");

    int m;
    while((m = Menu()) != 4){
        switch(m){
            case 1:
                printf("\n!!! Isilah data pendaftar di bawah dengan BENAR !!!\n");
                insertPendaftar(&pendaftar);
                break;
            case 2:
                tampilPendaftar(pendaftar);
                break;
            case 3:
                //Melihat daftar antrian seluruhnya
                queue_list = FCopyList(pendaftar);
                sortListQueue(&queue_list);
                tampilPendaftar(queue_list);

                //Melihat antrian per kategori
                printf("Do u want to filter this queue (y/t) ? ");
                fflush(stdin);
                scanf("%c", &ActiveSortCategory);
                if(ActiveSortCategory=='y'){
                    system("cls");
                    MenuSortList(pendaftar);
                }
                break;
            default :
                printf("Wrong input menu, please try again . . .\n");
                break;
        }
        system("pause");
        system("cls");
    }

    DelAll(&pendaftar);

    return 0;
}
