#include <stdio.h>
#include "DynamicLinkedList.h"

void createInfo(List *L, int n){
    infotype X;

    for(int i=0; i<n; i++){
        fflush(stdin);
        printf("Nilai SDA Mahasiswa ke - %d\n", i+1);
        printf("Nama  : ");
        scanf("%30[^\n]s", X.Nama);
        printf("Nilai : ");
        scanf("%d", &X.Nilai);
        InsVLast(&(*L), X);
        sortListQueue(&(*L));
        printf("\nShow Data :\n");
        PrintInfo(*L);
        system("pause");
        system("cls");
    }
}

int main(){
    List L;
    CreateList(&L);
    int N;

    printf("Jumlah Mahasiswa = ");
    scanf("%d", &N);

    system("pause");
    system("cls");

    createInfo(&L, N);

    return 0;
}
