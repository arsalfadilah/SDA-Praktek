#include<stdio.h>

int main(){
    int no = 1211;
    char strNo[4];
    char temp;


    //Formatting
    sprintf(strNo, "%d", no);
    if(no > 999){
//        strcpy(x.noPendaftar, strNo);
        printf("%s\n", strNo);
    } else if(no > 99){
        for(int i = 3; i>0; i--){
            strNo[i] = strNo[i-1];
        }
        strNo[0]='0';

//        strcpy(x.noPendaftar, strNo);
        printf("%s\n", strNo);
    } else if(no > 9){
//        printf("%c\n", strNo[0]);
//        printf("%c\n", strNo[1]);
        for(int i = 3; i>1; i--){
            strNo[i] = strNo[i-2];
//            printf("%c\n", strNo[i]);
        }
        strNo[0]='0';
        strNo[1]='0';

//        strcpy(x.noPendaftar, strNo);
        printf("%s\n", strNo);
    } else {
        temp = strNo[0];
        strNo[0]='0';
        strNo[1]='0';
        strNo[2]='0';
        strNo[3]=temp;
//        strcpy(x.noPendaftar, strNo);
        printf("%s\n", strNo);
    }

    return 0;
}

