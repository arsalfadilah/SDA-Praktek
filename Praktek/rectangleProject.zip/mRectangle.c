/* File             : mrectangle.h
 * Deskripsi        : alur program sesuai dengan kasus ADT Rectangle
 * Dibuat oleh      : kelas, Nim, Nama
 * Dimodifikasi oleh:  
 * Tanggal/versi    : 22 April 2021/ 01
 * ================================================================
 */

#include "rectangle.h"
#include <stdlib.h>
#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	
	return 0;
}
