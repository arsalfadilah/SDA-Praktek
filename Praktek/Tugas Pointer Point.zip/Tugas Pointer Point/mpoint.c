#include <stdio.h>
#include "point.h"
#include <math.h>
#include "boolean.h"

int main (){
	int X, Y;
	POINT P;
	int kuadran = 0;
	int N;

	scanf ("%d %d", &X, &Y);
	MakePoint(&P, X, Y);
	kuadran = Kuadran(P);

    PrintPoint(P);
    printf("\n");
	switch(kuadran){
		case 1 :
			NextX (&P);
			break;

		case 2 :
			PrevX(&P);
			break;

		case 3 :
			scanf ("%d", &N);
			PrevX_N(&P, N);
			break;

		case 4 :
			scanf ("%d", &N);
			NextX_N(&P, N);
			break;

		default :
			if (IsOrigin(P)) printf("Titik ada di titik origin");
			else if (IsOnSumbuX(P)) printf("Titik ada di sumbu x");
			else if (IsOnSumbuY(P)) printf("Titik ada di sumbu y");
	}
	PrintPoint(P);
}
