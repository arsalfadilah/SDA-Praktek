#include <stdio.h>
#include <time.h>
#include "list_queue.h"
#include <string.h>

int main () {
    List L;
    infotype x;
    strcpy(x.InfoKategori, "asas");
    strcpy(x.Kategori , "GURU");
    strcpy(x.Nama, "sdasf");
    strcpy(x.NoKtp , "asfa");
    CreateList(&L);
    InsVFirst(&L,  x);
    strcpy(x.InfoKategori, "asas");
    strcpy(x.Kategori , "BUMN");
    strcpy(x.Nama, "sdasf");
    strcpy(x.NoKtp , "asfa");
    InsVLast(&L, x);
    strcpy(x.InfoKategori, "asas");
    strcpy(x.Kategori , "BUMN");
    strcpy(x.Nama, "sdasf");
    strcpy(x.NoKtp , "asfa");
    InsVLast(&L, x);
    strcpy(x.InfoKategori, "asas");
    strcpy(x.Kategori , "DOSEN");
    strcpy(x.Nama, "sdasf");
    strcpy(x.NoKtp , "asfa");
    InsVLast(&L, x);
    strcpy(x.InfoKategori, "asas");
    strcpy(x.Kategori , "Lansia");
    strcpy(x.Nama, "sdasf");
    strcpy(x.NoKtp , "asfa");
    InsVLast(&L, x);
    PrintInfo(L);
    DelP(&L, "Lansia");
    PrintInfo(L);


   return(0);
}
