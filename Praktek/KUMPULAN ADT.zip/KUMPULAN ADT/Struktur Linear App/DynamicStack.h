/****** Include guard ******/
#ifndef SQueue
#define SQueue

/* An function declaration */


#endif

/****** Function definition ******/
