/*
 *	File          : boolean.h
 *	Nama Kelompok : Rifki Imam Abdillah <3411171044>
 *					Reji Pikriyansah  <3411171046>
 *	Deskripsi     : Header file boolean
 */

#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define boolean unsigned char
#endif
